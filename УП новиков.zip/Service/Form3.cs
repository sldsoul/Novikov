﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;

namespace Service
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            LoadSpecialists();
            SetupDataGridView();
        }

        private void SetupDataGridView()
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void LoadSpecialists()
        {
            try
            {
                BD.openSQL();

                string query = "SELECT Id, FullName, Position, PhoneNumber, IsActive FROM Specialists ORDER BY FullName";
                using (SqlDataAdapter adapter = new SqlDataAdapter(query, BD.conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;

                    if (dataGridView1.Columns.Contains("Id"))
                    {
                        dataGridView1.Columns["Id"].Visible = false;
                    }

                    if (dataGridView1.Columns.Contains("IsActive"))
                    {
                        dataGridView1.Columns["IsActive"].HeaderText = "Активен";
                    }
                }
            }
            finally
            {
                BD.closeSQL();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var specialistForm = new SpecialistForm(null);
            if (specialistForm.ShowDialog() == DialogResult.OK)
            {
                LoadSpecialists();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                int id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                BD.openSQL();

                string query = $"SELECT * FROM Specialists WHERE Id = {id}";
                using (SqlCommand cmd = new SqlCommand(query, BD.conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var specialist = new
                        {
                            Id = reader.GetInt32(0),
                            FullName = reader.GetString(1),
                            Position = reader.GetString(2),
                            PhoneNumber = reader.IsDBNull(3) ? "" : reader.GetString(3),
                            IsActive = reader.GetBoolean(4)
                        };

                        var specialistForm = new SpecialistForm(specialist);
                        if (specialistForm.ShowDialog() == DialogResult.OK)
                        {
                            LoadSpecialists();
                        }
                    }
                }
                BD.closeSQL();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var result = MessageBox.Show("Удалить выбранного специалиста?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    var selectedRow = dataGridView1.SelectedRows[0];
                    int id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                    BD.openSQL();

                    string deleteQuery = $"DELETE FROM Specialists WHERE Id = {id}";
                    using (SqlCommand cmd = new SqlCommand(deleteQuery, BD.conn))
                    {
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            LoadSpecialists();
                            MessageBox.Show("Специалист успешно удален!", "Успех",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                    BD.closeSQL();
                }
            }
        }
    }
}