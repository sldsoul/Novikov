﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Data.SqlClient;

namespace Service
{
    public static class BD
    {
        public static SqlConnection conn = new SqlConnection("Server=DESKTOP-HN337LN\\SQLEXPRESS;Database=ServiceDB;Trusted_Connection=True");

        public static void openSQL()
        {
            if (conn.State == System.Data.ConnectionState.Closed)
            {
                conn.Open();
            }
        }

        public static void closeSQL()
        {
            if (conn.State == System.Data.ConnectionState.Open)
            {
                conn.Close();
            }
        }
    }
}