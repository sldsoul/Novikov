﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Service
{
    public partial class StatisticsForm : Form
    {
        public StatisticsForm()
        {
            InitializeComponent();
            CalculateStatistics();
        }

        private void CalculateStatistics()
        {
            try
            {
                BD.openSQL();

                string totalQuery = "SELECT COUNT(*) FROM RepairRequests";
                int totalRequests = 0;
                using (SqlCommand cmd = new SqlCommand(totalQuery, BD.conn))
                {
                    totalRequests = Convert.ToInt32(cmd.ExecuteScalar());
                }

                string statusQuery = "SELECT Status, COUNT(*) FROM RepairRequests GROUP BY Status";
                int completedCount = 0, inProgressCount = 0, openCount = 0, waitingCount = 0;

                using (SqlCommand cmd = new SqlCommand(statusQuery, BD.conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string status = reader.GetString(0);
                        int count = reader.GetInt32(1);

                        switch (status)
                        {
                            case "завершена":
                                completedCount = count;
                                break;
                            case "в процессе ремонта":
                                inProgressCount = count;
                                break;
                            case "открыта заявка":
                                openCount = count;
                                break;
                            case "ожидание комплектующих":
                                waitingCount = count;
                                break;
                        }
                    }
                }

                label2.Text = $"Всего заявок: {totalRequests}";
                label3.Text = $"Завершено: {completedCount} ({CalculatePercentage(completedCount, totalRequests)}%)";
                label4.Text = $"В процессе: {inProgressCount} ({CalculatePercentage(inProgressCount, totalRequests)}%)";
                label5.Text = $"Открыто: {openCount} ({CalculatePercentage(openCount, totalRequests)}%)";
                label6.Text = $"Ожидание комплектующих: {waitingCount} ({CalculatePercentage(waitingCount, totalRequests)}%)";

                if (completedCount > 0)
                {
                    string avgTimeQuery = @"
                        SELECT AVG(DATEDIFF(day, CreatedDate, CompletionDate))
                        FROM RepairRequests 
                        WHERE Status = 'завершена' AND CompletionDate IS NOT NULL";

                    using (SqlCommand cmd = new SqlCommand(avgTimeQuery, BD.conn))
                    {
                        object result = cmd.ExecuteScalar();
                        if (result != DBNull.Value)
                        {
                            double avgDays = Convert.ToDouble(result);
                            label7.Text = $"Среднее время выполнения: {avgDays:F1} дней";
                        }
                        else
                        {
                            label7.Text = "Среднее время выполнения: нет данных";
                        }
                    }
                }
                else
                {
                    label7.Text = "Среднее время выполнения: нет завершенных заявок";
                }
                string equipmentQuery = @"
                    SELECT 
                        EquipmentType,
                        COUNT(*) as Количество,
                        SUM(CASE WHEN Status = 'завершена' THEN 1 ELSE 0 END) as Завершено,
                        SUM(CASE WHEN Status = 'в процессе ремонта' THEN 1 ELSE 0 END) as В_процессе
                    FROM RepairRequests 
                    WHERE EquipmentType IS NOT NULL AND EquipmentType != ''
                    GROUP BY EquipmentType
                    ORDER BY COUNT(*) DESC";

                using (SqlDataAdapter adapter = new SqlDataAdapter(equipmentQuery, BD.conn))
                {
                    System.Data.DataTable dt = new System.Data.DataTable();
                    adapter.Fill(dt);

                    dt.Columns.Add("Доля", typeof(string));
                    foreach (System.Data.DataRow row in dt.Rows)
                    {
                        int count = Convert.ToInt32(row["Количество"]);
                        row["Доля"] = $"{CalculatePercentage(count, totalRequests)}%";
                    }

                    dataGridView1.DataSource = dt;
                    dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
                }
            }
            finally
            {
                BD.closeSQL();
            }
        }

        private string CalculatePercentage(int part, int total)
        {
            if (total == 0) return "0.0";
            return ((double)part / total * 100).ToString("F1");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}