﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.SqlClient;

namespace Service
{
    public partial class Form2 : Form
    {
        private dynamic request;

        public Form2(dynamic existingRequest)
        {
            InitializeComponent();
            request = existingRequest;
            InitializeComboBoxes();
            LoadData();
        }

        private void InitializeComboBoxes()
        {
            comboBox1.Items.AddRange(new string[] {
                "открыта заявка",
                "в процессе ремонта",
                "ожидание комплектующих",
                "завершена"
            });

            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }
        }

        private void LoadData()
        {
            try
            {
                if (request == null)
                {
                    textBox1.Text = Guid.NewGuid().ToString("N").Substring(0, 8).ToUpper();
                    dateTimePicker1.Value = DateTime.Now;
                    comboBox1.SelectedIndex = 0;
                }
                else
                {
                    textBox1.Text = request.RequestNumber;
                    dateTimePicker1.Value = request.CreatedDate;
                    textBox2.Text = request.EquipmentType;
                    textBox3.Text = request.DeviceModel;
                    richTextBox1.Text = request.ProblemDescription;
                    textBox4.Text = request.CustomerName;
                    textBox5.Text = request.PhoneNumber;
                    richTextBox2.Text = request.Comments ?? "";
                    richTextBox3.Text = request.OrderedParts ?? "";
                    textBox6.Text = request.RepairCost?.ToString() ?? "";

                    if (!string.IsNullOrEmpty(request.Status))
                    {
                        comboBox1.Text = request.Status;
                    }
                    else
                    {
                        comboBox1.SelectedIndex = 0;
                    }
                }

                LoadSpecialists();

                if (request != null && !string.IsNullOrEmpty(request.ResponsiblePerson))
                {
                    comboBox2.Text = request.ResponsiblePerson;
                }
                else
                {
                    comboBox2.Text = "Не назначен";
                }
            }
            catch
            {
            }
        }

        private void LoadSpecialists()
        {
            try
            {
                BD.openSQL();

                string query = "SELECT FullName FROM Specialists WHERE IsActive = 1 ORDER BY FullName";
                using (SqlCommand cmd = new SqlCommand(query, BD.conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    comboBox2.Items.Clear();
                    comboBox2.Items.Add("Не назначен");

                    while (reader.Read())
                    {
                        comboBox2.Items.Add(reader.GetString(0));
                    }
                }
            }
            catch
            {
            }
            finally
            {
                BD.closeSQL();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox2.Text) ||
                string.IsNullOrWhiteSpace(textBox3.Text) ||
                string.IsNullOrWhiteSpace(richTextBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox4.Text) ||
                string.IsNullOrWhiteSpace(textBox5.Text) ||
                string.IsNullOrEmpty(comboBox1.Text))
            {
                MessageBox.Show("Заполните все обязательные поля");
                return;
            }

            try
            {
                BD.openSQL();

                if (request == null)
                {
                    string insertQuery = @"
                        INSERT INTO RepairRequests 
                        (RequestNumber, CreatedDate, EquipmentType, DeviceModel, ProblemDescription, 
                         CustomerName, PhoneNumber, Status, ResponsiblePerson, Comments, OrderedParts, RepairCost)
                        VALUES 
                        (@RequestNumber, @CreatedDate, @EquipmentType, @DeviceModel, @ProblemDescription,
                         @CustomerName, @PhoneNumber, @Status, @ResponsiblePerson, @Comments, @OrderedParts, @RepairCost)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, BD.conn))
                    {
                        cmd.Parameters.AddWithValue("@RequestNumber", textBox1.Text);
                        cmd.Parameters.AddWithValue("@CreatedDate", dateTimePicker1.Value);
                        cmd.Parameters.AddWithValue("@EquipmentType", textBox2.Text);
                        cmd.Parameters.AddWithValue("@DeviceModel", textBox3.Text);
                        cmd.Parameters.AddWithValue("@ProblemDescription", richTextBox1.Text);
                        cmd.Parameters.AddWithValue("@CustomerName", textBox4.Text);
                        cmd.Parameters.AddWithValue("@PhoneNumber", textBox5.Text);
                        cmd.Parameters.AddWithValue("@Status", comboBox1.Text);
                        cmd.Parameters.AddWithValue("@ResponsiblePerson", comboBox2.Text == "Не назначен" ? (object)DBNull.Value : comboBox2.Text);
                        cmd.Parameters.AddWithValue("@Comments", string.IsNullOrWhiteSpace(richTextBox2.Text) ? (object)DBNull.Value : richTextBox2.Text);
                        cmd.Parameters.AddWithValue("@OrderedParts", string.IsNullOrWhiteSpace(richTextBox3.Text) ? (object)DBNull.Value : richTextBox3.Text);

                        if (decimal.TryParse(textBox6.Text, out decimal cost))
                            cmd.Parameters.AddWithValue("@RepairCost", cost);
                        else
                            cmd.Parameters.AddWithValue("@RepairCost", DBNull.Value);

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    string updateQuery = @"
                        UPDATE RepairRequests SET
                            EquipmentType = @EquipmentType,
                            DeviceModel = @DeviceModel,
                            ProblemDescription = @ProblemDescription,
                            CustomerName = @CustomerName,
                            PhoneNumber = @PhoneNumber,
                            Status = @Status,
                            ResponsiblePerson = @ResponsiblePerson,
                            Comments = @Comments,
                            OrderedParts = @OrderedParts,
                            RepairCost = @RepairCost
                        WHERE Id = @Id";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, BD.conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", request.Id);
                        cmd.Parameters.AddWithValue("@EquipmentType", textBox2.Text);
                        cmd.Parameters.AddWithValue("@DeviceModel", textBox3.Text);
                        cmd.Parameters.AddWithValue("@ProblemDescription", richTextBox1.Text);
                        cmd.Parameters.AddWithValue("@CustomerName", textBox4.Text);
                        cmd.Parameters.AddWithValue("@PhoneNumber", textBox5.Text);
                        cmd.Parameters.AddWithValue("@Status", comboBox1.Text);
                        cmd.Parameters.AddWithValue("@ResponsiblePerson", comboBox2.Text == "Не назначен" ? (object)DBNull.Value : comboBox2.Text);
                        cmd.Parameters.AddWithValue("@Comments", string.IsNullOrWhiteSpace(richTextBox2.Text) ? (object)DBNull.Value : richTextBox2.Text);
                        cmd.Parameters.AddWithValue("@OrderedParts", string.IsNullOrWhiteSpace(richTextBox3.Text) ? (object)DBNull.Value : richTextBox3.Text);

                        if (decimal.TryParse(textBox6.Text, out decimal cost))
                            cmd.Parameters.AddWithValue("@RepairCost", cost);
                        else
                            cmd.Parameters.AddWithValue("@RepairCost", DBNull.Value);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            catch
            {
            }
            finally
            {
                BD.closeSQL();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}