﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Service
{
    public partial class SpecialistForm : Form
    {
        private dynamic specialist;

        public SpecialistForm(dynamic existingSpecialist)
        {
            InitializeComponent();
            specialist = existingSpecialist;
            LoadData();
        }

        private void LoadData()
        {

           if (specialist == null)
           {
                textBox1.Text = "";
                textBox2.Text = "";
                textBox3.Text = "";
                checkBox1.Checked = true;
           }
           else
           {
                textBox1.Text = specialist.FullName;
                textBox2.Text = specialist.Position;
                textBox3.Text = specialist.PhoneNumber ?? "";
                checkBox1.Checked = specialist.IsActive;
           }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) ||
                string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Заполните обязательные поля", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                BD.openSQL();

                if (specialist == null)
                {
                    string insertQuery = @"
                        INSERT INTO Specialists (FullName, Position, PhoneNumber, IsActive)
                        VALUES (@FullName, @Position, @PhoneNumber, @IsActive)";

                    using (SqlCommand cmd = new SqlCommand(insertQuery, BD.conn))
                    {
                        cmd.Parameters.AddWithValue("@FullName", textBox1.Text);
                        cmd.Parameters.AddWithValue("@Position", textBox2.Text);
                        cmd.Parameters.AddWithValue("@PhoneNumber", string.IsNullOrWhiteSpace(textBox3.Text) ? (object)DBNull.Value : textBox3.Text);
                        cmd.Parameters.AddWithValue("@IsActive", checkBox1.Checked);

                        cmd.ExecuteNonQuery();
                    }
                }
                else
                {
                    string updateQuery = @"
                        UPDATE Specialists SET
                            FullName = @FullName,
                            Position = @Position,
                            PhoneNumber = @PhoneNumber,
                            IsActive = @IsActive
                        WHERE Id = @Id";

                    using (SqlCommand cmd = new SqlCommand(updateQuery, BD.conn))
                    {
                        cmd.Parameters.AddWithValue("@Id", specialist.Id);
                        cmd.Parameters.AddWithValue("@FullName", textBox1.Text);
                        cmd.Parameters.AddWithValue("@Position", textBox2.Text);
                        cmd.Parameters.AddWithValue("@PhoneNumber", string.IsNullOrWhiteSpace(textBox3.Text) ? (object)DBNull.Value : textBox3.Text);
                        cmd.Parameters.AddWithValue("@IsActive", checkBox1.Checked);

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                Close();
            }
            finally
            {
                BD.closeSQL();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
    }
}