﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace Service
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeDatabase();
            LoadData();
            SetupDataGridView();
        }

        private void InitializeDatabase()
        {
            try
            {
                BD.openSQL();

                string checkTableQuery = @"
                    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='RepairRequests' and xtype='U')
                    CREATE TABLE RepairRequests (
                        Id INT PRIMARY KEY IDENTITY(1,1),
                        RequestNumber NVARCHAR(50) UNIQUE NOT NULL,
                        CreatedDate DATETIME NOT NULL,
                        EquipmentType NVARCHAR(100) NOT NULL,
                        DeviceModel NVARCHAR(100) NOT NULL,
                        ProblemDescription NVARCHAR(MAX) NOT NULL,
                        CustomerName NVARCHAR(200) NOT NULL,
                        PhoneNumber NVARCHAR(20) NOT NULL,
                        Status NVARCHAR(50) NOT NULL DEFAULT 'открыта заявка',
                        ResponsiblePerson NVARCHAR(200),
                        Comments NVARCHAR(MAX),
                        CompletionDate DATETIME,
                        OrderedParts NVARCHAR(MAX),
                        RepairCost DECIMAL(18,2)
                    )";

                using (SqlCommand cmd = new SqlCommand(checkTableQuery, BD.conn))
                {
                    cmd.ExecuteNonQuery();
                }

                string checkSpecialistsQuery = @"
                    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Specialists' and xtype='U')
                    CREATE TABLE Specialists (
                        Id INT PRIMARY KEY IDENTITY(1,1),
                        FullName NVARCHAR(200) NOT NULL,
                        Position NVARCHAR(100) NOT NULL,
                        PhoneNumber NVARCHAR(20),
                        IsActive BIT DEFAULT 1
                    )";

                using (SqlCommand cmd = new SqlCommand(checkSpecialistsQuery, BD.conn))
                {
                    cmd.ExecuteNonQuery();
                }

                string checkSpecialistsCountQuery = "SELECT COUNT(*) FROM Specialists";
                using (SqlCommand cmd = new SqlCommand(checkSpecialistsCountQuery, BD.conn))
                {
                    int count = (int)cmd.ExecuteScalar();

                    if (count == 0)
                    {
                        string insertSpecialistsQuery = @"
                            INSERT INTO Specialists (FullName, Position, PhoneNumber, IsActive) VALUES
                            ('Федоров Никита Нюругнович', 'Инженер', '+79142243490', 1),
                            ('Николаев Леонид Радиевич', 'Техник', '+79963154750', 1),
                            ('Сидорова Анна Владимировна', 'Мастер', '+79642244750', 1)";

                        using (SqlCommand insertCmd = new SqlCommand(insertSpecialistsQuery, BD.conn))
                        {
                            insertCmd.ExecuteNonQuery();
                        }
                    }
                }

                BD.closeSQL();
            }
            catch
            {
                Application.Exit();
            }
        }

        private void SetupDataGridView()
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ReadOnly = true;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            comboBox1.Items.AddRange(new string[] {
                "Все статусы",
                "открыта заявка",
                "в процессе ремонта",
                "завершена",
                "ожидание комплектующих"
            });
            comboBox1.SelectedIndex = 0;

            dateTimePicker1.Value = DateTime.Now.AddMonths(-1);
            dateTimePicker2.Value = DateTime.Now;
        }

        private void LoadData(string search = null, string statusFilter = null,
                            DateTime? startDate = null, DateTime? endDate = null)
        {
            try
            {
                BD.openSQL();

                string query = @"
                    SELECT 
                        Id,
                        RequestNumber,
                        CONVERT(VARCHAR, CreatedDate, 104) as CreatedDate,
                        EquipmentType,
                        DeviceModel,
                        CustomerName,
                        PhoneNumber,
                        Status,
                        ISNULL(ResponsiblePerson, 'Не назначен') as ResponsiblePerson
                    FROM RepairRequests 
                    WHERE 1=1";

                if (!string.IsNullOrEmpty(search))
                {
                    query += $" AND (RequestNumber LIKE '%{search}%' OR CustomerName LIKE '%{search}%' OR PhoneNumber LIKE '%{search}%')";
                }

                if (!string.IsNullOrEmpty(statusFilter) && statusFilter != "Все статусы")
                {
                    query += $" AND Status = '{statusFilter}'";
                }

                if (startDate.HasValue)
                {
                    query += $" AND CreatedDate >= '{startDate.Value:yyyy-MM-dd}'";
                }

                if (endDate.HasValue)
                {
                    query += $" AND CreatedDate <= '{endDate.Value.AddDays(1):yyyy-MM-dd}'";
                }

                query += " ORDER BY CreatedDate DESC";

                using (SqlDataAdapter adapter = new SqlDataAdapter(query, BD.conn))
                {
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    dataGridView1.DataSource = dt;

                    if (dataGridView1.Columns.Contains("Id"))
                    {
                        dataGridView1.Columns["Id"].Visible = false;
                    }
                }

                BD.closeSQL();
            }
            catch
            {
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var addForm = new Form2(null);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                LoadData();
                MessageBox.Show("Новая заявка успешно добавлена!");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var selectedRow = dataGridView1.SelectedRows[0];
                int id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                try
                {
                    BD.openSQL();

                    string query = $"SELECT * FROM RepairRequests WHERE Id = {id}";
                    using (SqlCommand cmd = new SqlCommand(query, BD.conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            var request = new
                            {
                                Id = reader.GetInt32(0),
                                RequestNumber = reader.GetString(1),
                                CreatedDate = reader.GetDateTime(2),
                                EquipmentType = reader.GetString(3),
                                DeviceModel = reader.GetString(4),
                                ProblemDescription = reader.GetString(5),
                                CustomerName = reader.GetString(6),
                                PhoneNumber = reader.GetString(7),
                                Status = reader.GetString(8),
                                ResponsiblePerson = reader.IsDBNull(9) ? null : reader.GetString(9),
                                Comments = reader.IsDBNull(10) ? null : reader.GetString(10),
                                CompletionDate = reader.IsDBNull(11) ? (DateTime?)null : reader.GetDateTime(11),
                                OrderedParts = reader.IsDBNull(12) ? null : reader.GetString(12),
                                RepairCost = reader.IsDBNull(13) ? (decimal?)null : reader.GetDecimal(13)
                            };

                            var editForm = new Form2(request);
                            if (editForm.ShowDialog() == DialogResult.OK)
                            {
                                LoadData();
                                MessageBox.Show("Заявка успешно обновлена!");
                            }
                        }
                    }
                }
                catch
                {
                }
                finally
                {
                    BD.closeSQL();
                }
            }
            else
            {
                MessageBox.Show("Выберите заявку для редактирования");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                var result = MessageBox.Show("Удалить выбранную заявку?", "Подтверждение",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    try
                    {
                        var selectedRow = dataGridView1.SelectedRows[0];
                        int id = Convert.ToInt32(selectedRow.Cells["Id"].Value);

                        BD.openSQL();

                        string deleteQuery = $"DELETE FROM RepairRequests WHERE Id = {id}";
                        using (SqlCommand cmd = new SqlCommand(deleteQuery, BD.conn))
                        {
                            int rowsAffected = cmd.ExecuteNonQuery();
                            if (rowsAffected > 0)
                            {
                                LoadData();
                                MessageBox.Show("Заявка успешно удалена!");
                            }
                        }

                        BD.closeSQL();
                    }
                    catch
                    {
                    }
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var statsForm = new StatisticsForm();
            statsForm.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.Trim();
            string statusFilter = comboBox1.SelectedItem?.ToString();
            LoadData(searchText, statusFilter, dateTimePicker1.Value, dateTimePicker2.Value);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var specialistsForm = new Form3();
            specialistsForm.ShowDialog();
            LoadData();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string searchText = textBox1.Text.Trim();
            string statusFilter = comboBox1.SelectedItem?.ToString();
            LoadData(searchText, statusFilter, dateTimePicker1.Value, dateTimePicker2.Value);
        }
    }
}